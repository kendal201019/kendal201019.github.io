# The next evolution of this program is to make it faster by maybe creating an excel file where:
# 1) We can input data for all applicants
# 2) This program gathers that data and makes all the appropriate computations
# 3) Makes a decision on the best tenant to chose based on the highest score possible
# 4) Additional criteria to add:
#   a) Add eviction history last 24 or 48 months
        #1) No evictions 100 points, 1 eviction 50 points, more than two 0 points.

def credit_scores(applicants):
    if applicants == 1:
        credit_score = int(input('Enter applicant credit score: '))

    else:
         i = 1
         credit_score = 0
         while i <= applicants:
            score = int(input('Enter applicant {} credit score: '.format(i)))
            credit_score = credit_score + score
            i = i + 1

    final_score = credit_score / applicants
    avg_credit = final_score

    if final_score < 600:
        score_credit = 0
    elif final_score >= 600 and final_score < 650:
        score_credit = 25
    elif final_score >= 650 and final_score < 700:
        score_credit = 50
    elif final_score >= 700 and final_score < 750:
        score_credit = 75
    elif final_score >= 750:
        score_credit = 100

    return score_credit, final_score

def income_rent_ratio(applicants):
    if applicants == 1:
        income = int(input('Enter applicant monthly income: '))

    else:
        i = 1
        income = 0
        while i <= applicants:
            inc = int(input('Enter applicant {} monthly income: '.format(i)))
            income = income + inc
            i = i + 1

    final_income = income / rent_amount

    income_rentratio = final_income
    if income_rentratio < 3:
        income_rent = 0
    elif income_rentratio >= 3 and income_rentratio < 4:
        income_rent = 25
    elif income_rentratio >= 4 and income_rentratio < 5:
        income_rent = 50
    elif income_rentratio >= 5 and income_rentratio < 6:
        income_rent = 75
    elif income_rentratio >= 6:
        income_rent = 100

    return income_rent, income

def emp_lenght(applicants):
    if applicants == 1:
        lenght_total = int(input("Enter lenght of employment (months): "))

    else:
        i = 1
        lenght_total = 0
        while i <= applicants:
            lenght_1 = int(input('Enter applicant {} lenght of employment: '.format(i)))
            lenght_total = lenght_total + lenght_1
            i = i + 1

    lenght_employment = lenght_total / applicants

    if lenght_employment < 12:
        employment_score = 0
    elif lenght_employment >= 12 and lenght_employment < 24:
        employment_score = 25
    elif lenght_employment >= 24 and lenght_employment < 36:
        employment_score = 50
    elif lenght_employment >= 36 and lenght_employment < 48:
        employment_score = 75
    elif lenght_employment >= 48:
        employment_score = 100
    return employment_score

def landlord_ref(applicants):
    if applicants == 1:
        ref = int(input("Enter total # of Landlord References: "))
    else:
        i = 1
        ref = 0
        while i <= applicants:
            landref= int(input('Enter applicant {} # of Landlord references: '.format(i)))
            ref = landref + ref
            i = i + 1

    landlord_references = ref / applicants

    if landlord_references >= 1 and landlord_references < 2:
        references = 25
    elif landlord_references >= 2:
        references = 50
    elif landlord_references < 1:
        references = 0
    return references

def med_collections(applicants):
    if applicants == 1:
        collect = int(input("Enter total # of Non Medical Collections: "))
    else:
        i = 1
        collect = 0
        while i <= applicants:
            amount= int(input('Enter applicant {} # of Non Medical Collections: '.format(i)))
            collect = collect + amount
            i = i + 1

    non_medical_collections = collect / applicants

    if non_medical_collections == 0:
        collections = 100
    elif non_medical_collections >= 0 and non_medical_collections <= 1:
        collections = 50
    elif non_medical_collections > 1 and non_medical_collections <= 3:
        collections = 25
    elif non_medical_collections >= 3:
        collections = 0

    return collections

def rent_debt_income(applicants):
    if applicants == 1:
        debt = int(input("Enter total amount of monthly debt applicant pays:  "))
    else:
        i = 1
        debt = 0
        while i <= applicants:
            amount= int(input('Enter total amount of monthly debt applicant {} pays:  '.format(i)))
            debt = debt + amount
            i = i + 1

    rent_debt_income = ((debt + rent_amount) * 100) / total_income

    if rent_debt_income >= 50:
        ir_score = 0
    elif rent_debt_income >= 30 and rent_debt_income < 50:
        ir_score = 25
    elif rent_debt_income >= 21 and rent_debt_income < 30:
        ir_score = 50
    elif rent_debt_income >= 10 and rent_debt_income < 21:
        ir_score = 75
    elif rent_debt_income < 10:
        ir_score = 100

    return ir_score

def pay_deliq(applicants):
    if applicants == 1:
        deliq = int(input("Enter amount of times applicant has been late last 12 months: "))
    else:
        i = 1
        deliq = 0
        while i <= applicants:
            amount= int(input('Enter amount of times applicant {} has been late last 12 months: '.format(i)))
            deliq = deliq + amount
            i = i + 1

    payment_deliquencies = deliq / applicants

    if payment_deliquencies < 1:
        delq_score = 100
    elif payment_deliquencies >= 1 and payment_deliquencies < 2:
        delq_score = 50
    elif payment_deliquencies >= 2 and payment_deliquencies < 3:
        delq_score = 25
    elif payment_deliquencies >= 3:
        delq_score = 0

    return delq_score

def len_address(applicants):
    if applicants == 1:
        address = int(input("Enter amount of time applicant has rented at current address: "))
    else:
        i = 1
        address = 0
        while i <= applicants:
            amount= int(input('Enter amount of time applicant {} has rented at current address: '.format(i)))
            address = address + amount
            i = i + 1

    lenght_address = address / applicants

    if lenght_address < 12:
        score_add = 0
    elif lenght_address >= 12 and lenght_address < 24:
        score_add = 25
    elif lenght_address >= 24 and lenght_address < 36:
        score_add = 50
    elif lenght_address >= 36 and lenght_address < 48:
        score_add = 75
    elif lenght_address >= 48:
        score_add = 100

    return score_add, address


applicants = int(input('Number of Applicants: '))
applicants_names = input('Enter names of all applicants: ')
app_date = input('Date of application: ')
app_rev = input('Date reviewed: ')
rent_amount = int(input('Enter Monthly Rent Cost: '))

score_1, credit_avg = credit_scores(applicants)
score_2, total_income = income_rent_ratio(applicants)
score_3 = emp_lenght(applicants)
score_4 = landlord_ref(applicants)
score_5 = med_collections(applicants)
score_6 = rent_debt_income(applicants)
score_7 = pay_deliq(applicants)
score_8, score_add = len_address(applicants)


credit_score = credit_avg


total_score = score_1 + score_2 + score_3 + score_4 + score_5 + score_6 + score_7 + score_8

if total_score < 300:
    decision = 'Not approved'
elif total_score >= 300 and total_score < 375:
    decision = 'Approved w/ sec. dep 2x & cosigner'
elif total_score >= 375 and total_score < 425:
    decision = 'Approved w/ sec. dep 2x'
elif total_score >= 425:
    decision = 'Approved'

if credit_score >= 600:
    add_req = ''
elif credit_score >= 550 and credit_score < 600:
    add_req = '2x sec Deposit'
elif credit_score >= 500 and credit_score < 550:
    add_req = '2x sec deposit & 3 months of rent saved in a savings account'
elif credit_score < 500:
    add_req = '2x sec deposit, 3 months rent in a savings account, and a cosigner'

if score_add <= 6:
    add_req2 = '2x deposit and or co-signer'
else:
    add_req2 = ''


print()
print('Application Decision for: ', applicants_names)
print('Application date: ', app_date, 'Reviewed date: ', app_rev)
print()
print('Score for applicant(s) credit scores:', score_1)
print('Score for income to rent multiple:', score_2)
print('Score for Employment lenght: ', score_3)
print('Score for lenght at current address: ', score_8)
print('Score for Landlord References: ', score_4)
print('Score for Non-Medical Collections: ', score_5)
print('Score for Rent & Debt to income: ', score_6)
print('Score for Payment deliquencies: ', score_7)
print()
print('Total score for applicant(s):', total_score)
print('Application Decision:', decision)
print()
print('additional requierments below: ')
print('Credit related requirements: ', add_req)
print('Other additional requirements: ', add_req2)

